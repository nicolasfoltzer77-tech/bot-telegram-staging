# Bot API (FastAPI) — Telegram-ready Starter

Squelette **prêt pour Codex (Web)** avec:
- Endpoint `/bot/chat` (démo)
- Notifications **Telegram** optionnelles (démarrage, heartbeat, open/close trade)
- Tests `pytest` 100% **offline**
- Lint `ruff`
- CI GitHub Actions

## Lancer en local

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pip install -r requirements-dev.txt
uvicorn app.main:app --reload
```

Docs : http://127.0.0.1:8000/docs

## Telegram (optionnel)

Définis ces variables d’environnement pour activer l’envoi de messages Telegram :
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

Quand elles sont présentes :
- Un message *“🚀 Bot started”* est envoyé au démarrage.
- `GET /status/heartbeat` enverra un *heartbeat*.
- `POST /trade/open` et `POST /trade/close` déclenchent des notifications de trades.

> Les tests restent **offline** : le notificateur Telegram utilise un **sender injecté**
> remplacé par un *fake* en tests. Aucun appel réseau réel pendant la CI/sandbox.

## Tests & Qualité

```bash
pytest -q
ruff check . && ruff format --check .
```

## Structure

```
app/
├─ main.py
├─ notify.py
├─ routers/
│  ├─ bot.py
│  ├─ status.py
│  └─ trade.py
└─ schemas/
   ├─ bot.py
   └─ trade.py
tests/
.github/workflows/ci.yml
AGENTS.md
requirements.txt
requirements-dev.txt
pyproject.toml
.env.sample
```

