import pytest
from app.notify import TelegramNotifier


class FakeSender:
    def __init__(self):
        self.calls = []

    async def __call__(self, url: str, payload: dict):
        self.calls.append((url, payload))


@pytest.mark.asyncio
async def test_telegram_notifier_builds_request():
    fake = FakeSender()
    n = TelegramNotifier(token="T0K3N", chat_id="123", sender=fake)
    await n.send_text("Hello")
    assert len(fake.calls) == 1
    url, payload = fake.calls[0]
    assert "api.telegram.org" in url and "T0K3N" in url
    assert payload == {"chat_id": "123", "text": "Hello"}
