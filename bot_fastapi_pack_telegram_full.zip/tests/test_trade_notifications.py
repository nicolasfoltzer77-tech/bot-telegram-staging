import pytest
from httpx import AsyncClient

from app.main import app
from app.notify import BaseNotifier, set_notifier


class CaptureNotifier(BaseNotifier):
    def __init__(self):
        self.messages = []

    async def send_text(self, text: str) -> None:
        self.messages.append(text)


@pytest.mark.asyncio
async def test_trade_open_close_notifications():
    cap = CaptureNotifier()
    set_notifier(cap)

    async with AsyncClient(app=app, base_url="http://test") as ac:
        r = await ac.post("/trade/open", json={"symbol": "BTCUSDT", "side": "buy", "qty": 1.0, "price": 50000})
        assert r.status_code == 200
        r = await ac.post("/trade/close", json={"symbol": "BTCUSDT", "side": "buy", "qty": 1.0, "price": 51000, "pnl": 1000})
        assert r.status_code == 200

    assert any("OPEN" in m for m in cap.messages)
    assert any("CLOSE" in m for m in cap.messages)
