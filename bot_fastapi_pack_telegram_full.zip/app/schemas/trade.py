from pydantic import BaseModel, Field
from typing import Literal


Side = Literal["buy", "sell"]


class TradeOpenRequest(BaseModel):
    symbol: str = Field(..., examples=["BTCUSDT"])
    side: Side = Field(..., examples=["buy"])
    qty: float = Field(..., gt=0)
    price: float = Field(..., gt=0)


class TradeCloseRequest(BaseModel):
    symbol: str = Field(..., examples=["BTCUSDT"])
    side: Side = Field(..., examples=["buy"])
    qty: float = Field(..., gt=0)
    price: float = Field(..., gt=0)
    pnl: float = Field(..., description="Profit/loss realized for the trade")
