from __future__ import annotations
from typing import Optional, Callable, Awaitable
import os

try:
    import httpx  # type: ignore
except Exception:  # pragma: no cover
    httpx = None  # type: ignore


class BaseNotifier:
    async def send_text(self, text: str) -> None:  # pragma: no cover
        raise NotImplementedError


class NullNotifier(BaseNotifier):
    async def send_text(self, text: str) -> None:
        return None


class TelegramNotifier(BaseNotifier):
    def __init__(
        self,
        token: str,
        chat_id: str,
        sender: Optional[Callable[[str, dict], Awaitable[None]]] = None,
    ) -> None:
        self.token = token
        self.chat_id = chat_id
        self._sender = sender or self._http_sender

    async def _http_sender(self, url: str, payload: dict) -> None:
        if httpx is None:
            raise RuntimeError("httpx not available for Telegram notifier")
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(url, json=payload)

    async def send_text(self, text: str) -> None:
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": text}
        await self._sender(url, payload)


_notifier: BaseNotifier = None  # type: ignore


def make_from_env() -> BaseNotifier:
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    if token and chat_id:
        return TelegramNotifier(token=token, chat_id=chat_id)
    return NullNotifier()


def get_notifier() -> BaseNotifier:
    return _notifier


def set_notifier(n: BaseNotifier) -> None:
    global _notifier
    _notifier = n


set_notifier(make_from_env())
