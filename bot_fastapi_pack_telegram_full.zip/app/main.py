from fastapi import FastAPI
from app.routers import bot
from app.routers import status as status_router
from app.routers import trade as trade_router
from app.notify import get_notifier

app = FastAPI(title="Bot API", version="0.2.0")


@app.on_event("startup")
async def _startup_notify():
    try:
        await get_notifier().send_text("🚀 Bot started")
    except Exception:
        # keep startup resilient in offline/CI
        pass


@app.get("/health")
def health() -> dict[str, bool]:
    return {"ok": True}


app.include_router(bot.router, prefix="/bot", tags=["bot"])
app.include_router(status_router.router, prefix="/status", tags=["status"])
app.include_router(trade_router.router, prefix="/trade", tags=["trade"])
