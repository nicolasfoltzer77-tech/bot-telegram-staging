from fastapi import APIRouter
from app.notify import get_notifier
from app.schemas.trade import TradeOpenRequest, TradeCloseRequest

router = APIRouter()


@router.post("/open")
async def trade_open(req: TradeOpenRequest) -> dict:
    msg = (
        f"📈 OPEN {req.side.upper()} {req.symbol} "
        f"qty={req.qty} price={req.price}"
    )
    await get_notifier().send_text(msg)
    return {"ok": True}


@router.post("/close")
async def trade_close(req: TradeCloseRequest) -> dict:
    msg = (
        f"📉 CLOSE {req.side.upper()} {req.symbol} "
        f"qty={req.qty} price={req.price} pnl={req.pnl}"
    )
    await get_notifier().send_text(msg)
    return {"ok": True}
