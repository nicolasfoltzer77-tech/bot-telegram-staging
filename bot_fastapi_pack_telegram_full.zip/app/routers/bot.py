from fastapi import APIRouter
from app.schemas.bot import ChatRequest, ChatResponse

router = APIRouter()


@router.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest) -> ChatResponse:
    text = (req.message or "").strip().lower()

    if any(g in text for g in ["bonjour", "hello", "salut"]):
        reply = "Salut ! Je suis un bot de démo. Dis-moi ce que tu veux faire 🙂"
    elif any(k in text for k in ["help", "aide"]):
        reply = "Commandes: GET /health, POST /bot/chat {message}. Ce bot est un squelette prêt pour ta logique."
    else:
        reply = f"Tu as dit: {req.message}"

    return ChatResponse(reply=reply)
