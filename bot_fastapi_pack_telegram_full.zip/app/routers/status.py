from fastapi import APIRouter
from app.notify import get_notifier

router = APIRouter()


@router.get("/heartbeat")
async def heartbeat() -> dict[str, str]:
    try:
        await get_notifier().send_text("✅ Heartbeat: bot is running")
    except Exception:
        pass
    return {"status": "alive"}
