# AGENTS.md — Guide pour l’agent (Codex)

## Mission & Priorités
1. Tous les tests passent.
2. Respecter l’archi et le style existants.
3. Petites PR (≈ < 400 lignes) avec docs et tests.
4. Zéro secret en clair, pas d’appels réseau non autorisés.

## Commandes standard
- Setup :
  ```bash
  python -m venv .venv && source .venv/bin/activate
  pip install -r requirements.txt
  pip install -r requirements-dev.txt
  ```
- Run : `uvicorn app.main:app --reload`
- Tests : `pytest -q`
- Lint/format : `ruff check . && ruff format .`

## Workflow attendu
1. Lire le code impacté et proposer un plan (3–5 puces).
2. Implémenter code + tests (happy path + erreurs).
3. Lancer lint + tests localement (aucun réseau réel).
4. Mettre à jour README/examples si besoin.
5. Ouvrir une PR (Conventional Commits) + checklist PR.

## Règles de code
- Python 3.11+, type hints, logging (pas de `print`).
- FastAPI + Pydantic pour I/O; handlers d’erreurs explicites.

## Tests
- `tests/test_*.py`, déterministes.
- Inclure cas 422/404 pour les endpoints.
- Aucune dépendance à Internet.

## Git
- Branches : `feat/<slug>`, `fix/<slug>`, `chore/<slug>`.
- Commits : Conventional Commits.
