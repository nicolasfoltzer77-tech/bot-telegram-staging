**Titre**: `feat: <résumé court>`

**Contexte**
- Pourquoi : …
- Quoi : …

**Comment tester**
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt -r requirements-dev.txt
pytest -q
```

**Checklist**
- [ ] Tests passent
- [ ] Lint/format ok
- [ ] README/docs mis à jour
- [ ] Pas de secrets / données perso
